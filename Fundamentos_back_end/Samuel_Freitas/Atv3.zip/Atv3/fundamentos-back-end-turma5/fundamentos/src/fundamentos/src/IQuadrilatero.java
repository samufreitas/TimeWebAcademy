package fundamentos.src;

public interface IQuadrilatero {
    double calcularArea();
}
