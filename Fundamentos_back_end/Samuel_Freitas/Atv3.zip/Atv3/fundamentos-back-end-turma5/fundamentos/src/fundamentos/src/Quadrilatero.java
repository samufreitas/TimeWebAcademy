package fundamentos.src;

public abstract class Quadrilatero {
    public abstract double calcularArea();
}
