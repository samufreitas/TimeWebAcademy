package br.ufac.sgcm.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;


import br.ufac.sgcm.dao.UsuarioDao;
import br.ufac.sgcm.model.Usuario;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class UsuarioController implements IController<Usuario>{

    Connection conexao;
    PreparedStatement ps;
    ResultSet rs;
    private UsuarioDao userDao;

    public UsuarioController() {
        userDao = new UsuarioDao();
    }

    @Override
    public int delete(Usuario objeto) {
        int registrosAfetados =  userDao.delete(objeto);
        return registrosAfetados;
    }

    @Override
    public List<Usuario> get() {
        List<Usuario> registros = userDao.get();
        return registros;
    }

    @Override
    public Usuario get(Long id) {
        Usuario registro = userDao.get(id);
        return registro;
    }

    @Override
    public List<Usuario> get(String termoBusca) {
        List<Usuario> registros = userDao.get(termoBusca);
        return registros;
    }

    @Override
    public Usuario processFormRequest(HttpServletRequest request, HttpServletResponse response) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Usuario> processListRequest(HttpServletRequest request) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int save(Usuario objeto) {
        // TODO Auto-generated method stub
        return 0;
    }

    public Usuario processLogin(HttpServletRequest req, HttpServletResponse res) {
        String submit = req.getParameter("submit");
        String paramNomeUsuario = req.getParameter("nome_usuario");
        String paramSenha = req.getParameter("senha");

        if (submit != null && paramNomeUsuario != null && !paramNomeUsuario.isEmpty() && paramSenha != null && !paramSenha.isEmpty()) {
            // Supondo que você tenha um método para validar o usuário em algum serviço
            Usuario item = validarUsuario(paramNomeUsuario, paramSenha);
            
            if (item != null) {
                HttpSession session = req.getSession();
                session.setAttribute("usuarioLogado", item);

                try {
                    res.sendRedirect("index.jsp");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return item;
            } else {
                HttpSession session = req.getSession();
                session.setAttribute("loginError", "Nome de usuário ou senha inválidos.");
                try {
                    res.sendRedirect("login.jsp");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }
    private Usuario validarUsuario(String nomeUsuario, String senha) {
        Usuario registro = new Usuario();
        String sql = "SELECT nome_usuario, ativo, senha FROM usuario WHERE nome_usuario = ? AND senha = ?";
        try {
            ps = conexao.prepareStatement(sql);
            ps.setString(1, nomeUsuario);
            ps.setString(2, senha);
            rs = ps.executeQuery();
            if (rs.next()) {
                registro.setNomeUsuario(rs.getString("nome_usuario"));
                registro.setAtivo(rs.getBoolean("ativo"));
                registro.setSenha(rs.getString("senha"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return registro;
        
    }
}
