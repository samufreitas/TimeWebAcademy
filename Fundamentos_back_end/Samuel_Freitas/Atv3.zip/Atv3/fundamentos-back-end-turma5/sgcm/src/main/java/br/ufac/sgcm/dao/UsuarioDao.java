package br.ufac.sgcm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.ufac.sgcm.model.Unidade;
import br.ufac.sgcm.model.Usuario;

public class UsuarioDao implements IDao<Usuario>{

    private Connection conexao;
    private PreparedStatement ps;
    private ResultSet rs;

    public UsuarioDao() {
        this.conexao = ConexaoDB.getConexao();
    }
    @Override
    public int delete(Usuario objeto) {
        int registrosAfetados = 0;
        String sql = "DELETE FROM usuario WHERE id = ?";
        try {
            ps = conexao.prepareStatement(sql);
            ps.setLong(1, objeto.getId());
            registrosAfetados = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return registrosAfetados;
    }

    @Override
    public List<Usuario> get() {
        List<Usuario> registros = new ArrayList<>();
        String sql = "SELECT * FROM usuario";
        try {
            ps = conexao.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Usuario registro = new Usuario();
                registro.setId(rs.getLong("id"));
                registro.setNomeCompleto(rs.getString("nome_completo"));
                registro.setNomeUsuario(rs.getString("nome_usuario"));
                registro.setSenha(rs.getString("senha"));
                registro.setAtivo(rs.getBoolean("ativo"));
                registro.setPapel(rs.getString("papel"));
                registros.add(registro);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return registros;
    }

    @Override
    public Usuario get(Long id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Usuario> get(String termoBusca) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int insert(Usuario objeto) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int update(Usuario objeto) {
        // TODO Auto-generated method stub
        return 0;
    }

}
